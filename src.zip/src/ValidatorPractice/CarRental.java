package ValidatorPractice;

import ValidatorPracticeDTO.RentACarException;
import ValidatorPracticeDTO.RentalDTO;

public class CarRental {
	public CarRental() {
		super();
	}
	
public static void validate(RentalDTO rentalDTO) throws RentACarException{
		// WRITE YOUR CODE HERE
		
	}
	
	public static Boolean isValidContactNumber(Long mobileNumber) {
		// WRITE YOUR CODE HERE
		
		return null;
		
	}
	
	
}
