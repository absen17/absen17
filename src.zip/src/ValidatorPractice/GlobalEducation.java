package ValidatorPractice;


import ValidatorPracticeDTO.GlobalEducationException;
import ValidatorPracticeDTO.StudentDTO;

public class GlobalEducation {
	public GlobalEducation() {
		super();
	}
	
public static void validateStudent(StudentDTO studentDTO) throws GlobalEducationException{
		// WRITE YOUR CODE HERE
	}
	
	public static Boolean isValidIntakeYear(Integer intakeYear) {
		// WRITE YOUR CODE HERE
		
		return null;
		
	}

}
