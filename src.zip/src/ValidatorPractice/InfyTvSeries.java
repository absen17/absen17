package ValidatorPractice;

import java.time.LocalDate;

import ValidatorPracticeDTO.SeriesBookingException;
import ValidatorPracticeDTO.UserDTO;

public class InfyTvSeries {

		public InfyTvSeries() {
			super();
		}
		
	public static void validateUser(UserDTO userDTO) throws SeriesBookingException{
			// WRITE YOUR CODE HERE
			
		}
		
		public static Boolean isValidRegDate(LocalDate regDate) {
			// WRITE YOUR CODE HERE
			
			return null;
			
		}
		
		
	}


