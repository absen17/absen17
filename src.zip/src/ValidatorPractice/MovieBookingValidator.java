package ValidatorPractice;

import ValidatorPracticeDTO.MovieBookingDTO;
import ValidatorPracticeDTO.MovieBookingException;

public class MovieBookingValidator {
	public MovieBookingValidator() {
		super();
	}
	
public static void validate(MovieBookingDTO movieBookingDTO) throws MovieBookingException{
		// WRITE YOUR CODE HERE
		
	}
	
	public static Boolean isValidPaymentType(String paymentType) throws MovieBookingException {
		// WRITE YOUR CODE HERE
		
		return null;
		
	}
	
	public static Boolean isValidCustomerPhoneNo(Long customerPhoneNo) throws MovieBookingException {
		// WRITE YOUR CODE HERE
		
		return null;
		
	}

}
