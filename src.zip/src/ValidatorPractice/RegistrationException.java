package ValidatorPractice;

public class RegistrationException extends Exception {

	public RegistrationException(String string) {
		// TODO Auto-generated constructor stub
	}

}
