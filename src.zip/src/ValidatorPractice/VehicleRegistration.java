package ValidatorPractice;

public class VehicleRegistration {
	public VehicleRegistration() {
		super();
	}
	
public static void validateRegistration(RegistrationDTO registrationDTO) throws RegistrationException{
		// WRITE YOUR CODE HERE
		if(!isValidVehicleNumber(registrationDTO.getvehicleNumber())) {
			throw new RegistrationException("RegistrationValidator.INVALID_VEHICLE_NUMBER");
		}
	}
	
	public static Boolean isValidVehicleNumber(String vehicleNumber) {
		// WRITE YOUR CODE HERE
//		String regex= ("[A-Z]{2}\\s[0-9]{2}\\s[A-Z]{2}\\s[0-9]{4}");
		if(vehicleNumber.matches("[A-Z]{2}\\s[0-9]{2}\\s[A-Z]{2}\\s[0-9]{4}")) {
			return true;
		}
		return false;
	}	
}
