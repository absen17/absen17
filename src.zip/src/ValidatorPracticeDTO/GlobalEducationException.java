package ValidatorPracticeDTO;

public class GlobalEducationException extends Exception {

	public GlobalEducationException(String string) {
		// TODO Auto-generated constructor stub
	}

}
