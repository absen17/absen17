package ValidatorPracticeDTO;

public class LotteryBookingException extends Exception {

}
