package ValidatorPracticeDTO;

public class ParticipantDTO {

}
