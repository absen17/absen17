package ValidatorPracticeDTO;

public class RentACarException extends Exception {

}
