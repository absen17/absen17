package ValidatorPracticeDTO;

public class RentalDTO {

}
