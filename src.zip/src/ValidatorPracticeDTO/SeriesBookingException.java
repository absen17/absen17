package ValidatorPracticeDTO;

public class SeriesBookingException extends Exception {

}
