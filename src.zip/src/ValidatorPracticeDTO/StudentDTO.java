package ValidatorPracticeDTO;

public class StudentDTO {

	public Integer getintakeYear;

}
