package ValidatorPracticeDTO;

public class UserDTO {

}
